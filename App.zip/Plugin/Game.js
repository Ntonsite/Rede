var Game = {
	Sidescroller: function(canvas, observer) {
		observer.x > 0 && observer.x < this.Width - canvas.Width() ? canvas.Viewport(-observer.x, 0) : null ; 
	},
	Viewport: function(canvas, observer) {
		var x = observer.x > 0 && observer.x < this.Width - canvas.Width() ?  -observer.x : 0 ;
		var y = observer.y > 0 && observer.y < this.Height - canvas.Height() ? -observer.y : 0 ;
		canvas.Viewport(x, y);
	},
	Effect: function(canvas, a, callback) {
		if(a && callback) {
			canvas.context.save();
			canvas.context.globalCompositeOperation = a; callback(); 
			canvas.context.restore();
		}
	},
	Shake: function(canvas, a, callback) {
		if(a > 0) {
			var dx = Math.random() * a, dy = Math.random() * a;
			canvas.Context().save();
			canvas.Context().translate(dx, dy);
			callback ? callback(a) : null ;
			canvas.Context().restore();
		} else {
			callback ? callback(a) : null ;
		}
	},
	Controllers: function(a) {
		var selector = UI.Selector(a);
		selector.On("mousedown touchstart").Response(function(e) {
			Game.drag = true;
			Game.x = Game.dx = Game.px = (e.touches ? e.touches[0].pageX - e.touches[0].target.offsetLeft : e.offsetX);
			Game.y = Game.dy = Game.py = (e.touches ? e.touches[0].pageY - e.touches[0].target.offsetTop : e.offsetY);
		}, false);
		selector.On("mousemove touchmove").Response(function(e) {
			var xUp = Game.px = (e.touches ? e.touches[0].pageX - e.touches[0].target.offsetLeft : e.offsetX);
			var yUp = Game.py = (e.touches ? e.touches[0].pageY - e.touches[0].target.offsetTop : e.offsetY);
			if (!Game.dx || ! Game.dy) return;
			var xDiff = Game.dx - xUp, yDiff = Game.dy - yUp;
			if(Math.abs(xDiff) + Math.abs(yDiff) > 50) {
				if (Math.abs(xDiff) > Math.abs(yDiff)) {
					xDiff > 0 ? Game.left = true : Game.right = true ;
				} else {
					yDiff > 0 ? Game.up = true : Game.down = true ;
				}
				Game.dx = null; Game.dy = null;
			}
		}, false);
		selector.On("mouseup mouseleave touchend").Response(function(e) {
			Game.drag = false;
		}, false);
		On("keydown").Response(function (e) {
			Game.keys = (Game.keys || []); Game.keys[e.keyCode] = true;
		});
		On("keyup").Response(function (e) {
			Game.keys[e.keyCode] = false;
		});
		return selector;
	},
	Resize: function(canvas, w, h) {
		function resize() {
			canvas.Cache(function() {
				Game.Width = w; canvas.Width(w);
				Game.Height = h; canvas.Height(h);
			});
		}
		document.addEventListener ? resize() : null ;
		window.addEventListener("resize", resize);
		window.addEventListener("orientationchange", function() {
			resize();
			switch(window.orientation) {
				case -90 || 90: break; default: resize(); break;
			}
		});
	},
	Open: function(a) {
		Game.x = false; Game.y = false; Game.px = false; Game.py = false;
		Game.Identity ? clearInterval(Game.Identity) : null ; Game.Identity = 0;
		Game.Identity = a ? setInterval(a().Activity, 20) : 0 ; Game.Activity = a ? a().Activity : null ;
	},
	Audio: {
		Play: function(a, b) {
			var sound = new Sound(a);
			b ? this.Stop() : null; V["spk"] = sound; V["spk"].play();
		},
		Stop: function() {
			V["spk"] ? V["spk"].stop() : null ; V["spk"] = null;
		}
	},
	Resume: function() {
		Game.Activity ? Game.Open(Game.Activity) : null ;
	},
	Pause: function() {
		Game.Identity ? clearInterval(Game.Identity) : null ; Game.Identity = 0;
	},
	Wait: function(n) {
		if ((Game.frame/n) % 1 == 0) { return true; }
		return false;
	},
	frame: 0, Width: 0, Height: 0, Identity: 0, Activity: null
};
function Item(a) {
	this.image = a.image ? a.image : a.sheet ;
	this.color = a.color;
	this.background = a.background;
	this.width = a.width;
	this.height = a.height;
	this.x = a.x;
	this.y = a.y;
	this.text = a.text;
	this.font = a.font;
	this.label = a.label;
	this.align = a.align;
	this.stroke = a.stroke;
	this.rows = a.rows || 1;
	this.cols = a.cols || 1;
	this.speed = a.speed || 0 ;
	this.speedX = 0;
	this.speedY = 0; 
	this.gravity = 0.05;
	this.gravitySpeed = 0;
	this.dim = {};
	this.padding = 0;
	this.bounce = 0;
	this.wrap = true;
	this.scroll = false;
	this.rotation = 0;
	this.render = function(canvas) {
		if (a.image && a.rotation) {
			canvas.Image(this.image).Rotate({ x: this.x, y: this.y, width: this.width, height: this.height, rotation: this.rotation });
		} else if (a.image) {
			canvas.Image(this.image).Render({ x: this.x, y: this.y, width: this.width, height: this.height });
		} else if (a.sheet) {
			canvas.Image(this.image).Animate(this.x, this.y, this.width, this.height, this.rows, this.cols, this.speed);
		} else if (a.font && a.background) {
			this.dim = canvas.Text({ obj: this, text: this.text, x: this.x, y: this.y, width: this.width, height: this.height,
				align: "center", font: this.font, fill: this.color, rect: this.background, padding: this.padding, wrap: this.wrap });
		} else if (a.font) {
			this.dim = canvas.Text({ obj: this, text: this.text, label: this.label, x: this.x, y: this.y, width: this.width, height: this.height,
				align: this.align, stroke: this.stroke, fill: this.color, font: this.font, padding: this.padding, wrap: this.wrap });
		} else {
			canvas.Rectangle({ rect: [this.x, this.y, this.width, this.height], fillstyle: this.color });
		}
	};
	this.stop = function() {
		this.speedX = 0;
		this.speedY = 0;
	};
	this.rotate = function() {
		this.rotation += this.speedX % 360;
	};
	this.move = function() {
		this.gravitySpeed += this.gravity;
		this.x += this.speedX;
		this.y += this.speedY + this.gravitySpeed;
		if (this.scroll) { if (this.x == -(this.width)) { this.x = 0; } }
	};
	this.ground = function(canvas, height) {
		var bottom = canvas.Height() - height - this.height;
		if (this.y > bottom) {
			this.y = bottom;
			this.speedX = 0; this.speedY = 0;
			this.gravitySpeed = -(this.gravitySpeed * this.bounce);
		}
	};
	this.collide = function(obstacle) {
		var myleft = this.x;
		var myright = this.x + (this.width/this.cols);
		var mytop = this.y;
		var mybottom = this.y + (this.height/this.rows);
		var otherleft = obstacle.x;
		var otherright = obstacle.x + (obstacle.width/obstacle.cols);
		var othertop = obstacle.y;
		var otherbottom = obstacle.y + (obstacle.height/obstacle.rows);
		var crash = true;
		if ((mybottom < othertop) || (mytop > otherbottom) || (myright < otherleft) || (myleft > otherright)) {
			crash = false;
		}
		return crash;
	};
	this.clicked = function(a, b) {
		var myleft = a||this.dim.x||this.x;
		var myright = (a||this.dim.x||this.x) + (b||this.dim.width||this.width);
		var mytop = this.dim.y||this.y;
		var mybottom = (this.dim.y||this.y) + (this.dim.height||this.height);
		var clicked = true;
		if ((mybottom < Game.y) || (mytop > Game.y) || (myright < Game.x) || (myleft > Game.x)) {
			clicked = false;
		}
		return clicked;
	};
}
function Sound(filename) {
	this.audio = new Audio(Engine.Util.Convert.fromArrayBufferToURL(filename));
	this.play = function() {
		window.bufferArray = window.bufferArray ? window.bufferArray : new Object() ;
		var response = V[filename], promise = this.audio.play();
		if (promise !== undefined) {
			promise.then(function() {
			}).catch(function(error) {
				Engine.Web.Audio().Decode(response, function(buffer) {
					window.bufferArray[filename] = buffer;
					Engine.Web.Audio().Create.Buffer().Value(window.bufferArray[filename]).Connect().Start();
				}, function(error) {
					window.bufferArray[filename] ? Engine.Web.Audio().Create.Buffer().Value(window.bufferArray[filename]).Connect().Start() : null ;
				});
			});
		}
	};
	this.pause = function() {
		this.audio.pause();
	};
	this.stop = function() {
		this.audio ? this.audio.currentTime = 0 : null ;
		this.audio ? this.audio.pause() : null ;
	};
	this.loop = function() {
		if (typeof this.audio.loop == "boolean") {
			this.audio.loop = true;
		} else {
			this.audio.addEventListener("ended", function() { this.currentTime = 0; this.play(); }, false);
		}
	};
};