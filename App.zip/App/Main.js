function Main() {
	var canvas = V["canvas"], context = canvas.Context(), width = Game.Width, height = Game.Height; speed = 4;
	var idle = (V["player"] == 1 ? V["idle0.png"] : V["idle1.png"]), jump = (V["player"] == 1 ? V["jump0.png"] : V["jump1.png"]), 
		crouch = (V["player"] == 1 ? V["crouch0.png"] : V["crouch1.png"]), angle = 0, hits = 5, credits = "0"; V["V1"] = true;
	var background = new Item({ image: V["bg.png"], x: 0, y: 0, width: width, height: height });
	var ground = new Item({ color: "#00FF00", x: 0, y: height - 20, width: width, height: 20 });
	var player = new Item({ image: idle, x: width/2 - 40/2, y: height - 20 - 150 - 80, width: 80, height: 150 });
	var AA = new Item({ color: "#FF0000", width: 10, height: 100 });
	var A1 = new Item({ color: "#00FFFF", x: width/2 - 40/2, y: height - 20 - 80 - 20, width: 80, height: 150 });
	var A2 = new Item({ color: "#00FFFF", x: width/2 - 40/2, y: height - 20 - 80 - 20, width: 80, height: 150 });
	var ball = new Item({ sheet: V["ball.png"], width: 60, height: 20, rows: 1, cols: 3, speed: 10 });
	var report = new Item({ color: "#000000", font: "30px Arial", align: "center", x: width/2, y: height/2 - 30/2 });
	var menu = new Item({ color: "#000000", font: "30px Arial", align: "center", x: width/2, y: height/2 - 30/2 - 60 });
	var V1 = new Item({ image: V["V10.png"], x: 40, y: height - 140 - 50, width: 60, height: 140 });
	var V2 = new Item({  image: V["V20.png"], x: width - 60 - 40, y: height - 140 - 50, width: 60, height: 140 });
	var Stylish = function(o, text, color, font, x, y) {
		o.font = font; o.shadowColor = "black"; o.shadowBlur = 10; o.lineWidth = 10; o.strokeStyle = "white";
		o.strokeText(text, x, y); o.shadowBlur = 0; o.fillStyle = color; o.fillText(text, x, y); o.textBaseline = "middle"; o.textAlign = "center";
	};
	return {
		Activity: function() {
			canvas.Clear(width, height); Game.frame += 1;
			if(credits > 10) { speed = 5; } else if(credits > 30) { speed = 6; } else if(credits > 50) { speed = 7; }
			if((Game.keys && Game.keys[40] || Game.down) && player.y <= height - player.height - 20) {
				player.width = 80; player.height = 100; player.image = crouch;
			} else if(player.y < height - player.height - 80 - 20) {
				player.width = 80; player.height = 130; player.image = jump;
			} else {
				player.width = 80; player.height = 150; player.image = idle;
			}
			background.render(canvas);
			V1.render(canvas);
			V2.render(canvas);
			if(V["pause"] != true) {
				player.gravity = 0.1;
				player.move(canvas);
				player.ground(canvas, 50);
				player.render(canvas);
				Merge(AA).Object({ x: player.x + player.width/2 - AA.width/2, y: player.y + player.height/2 - AA.height/2 }); //.render(canvas);
				Merge(A1).Object({ x: player.x, y: player.y - height, height: height }); //.render(canvas);
				Merge(A2).Object({ x: player.x, y: player.y + player.height, height: height }); //.render(canvas);
				if(player.x < 80) { player.x = 80; }
				if(player.x > width - 80 - player.width ) {
					player.x = width - 80 - player.width; 
				}
				ball.move(canvas);
				ball.ground(canvas, 50);
				ball.render(canvas);
				if(ball.collide(AA)) {
					hits--; V["T1"] = false; V["T2"] = false; Game.Audio.Play("hit.mp3", true);
					if(V["V2"]) { V["V1"] = true; V["V2"] = false; }  else { V["V1"] = false; V["V2"] = true; }
				}
				Stylish(context, hits, "green", "30px verdana", width - 40, 40);
			}
			//angle = Math.atan((player.x + 40 / 2)/80) * (180 / Math.PI);
			(ball.x > A1.x && ball.x < A1.x + 3) || (ball.x > A2.x && ball.x < A2.x + 5) ? credits++ : null ;
			if(V["V1"]) {
				V1.image = V["V11.png"]; V2.image = V["V20.png"];
				if(V["T1"]) {
					ball.speedX = speed; ball.speedY = V["angle"];
				} else {
					V["V2"] = false; V["T1"] = true;
					ball.y = V1.y; ball.x = V1.x + 40/2; V["angle"] = -Random(2, 4);
				}
			} else if(V["V2"]) {
				V1.image = V["V10.png"]; V2.image = V["V21.png"];
				if(V["T2"]) {
					ball.speedX = -speed; ball.speedY = V["angle"];
				} else {
					V["V1"] = false; V["T2"] = true;
					ball.y = V2.y; ball.x = V2.x; V["angle"] = -Random(2, 4);
				}
			}
			if(ball.x < 80) {
				V["V1"] = true; V["V2"] = false; V["T2"] = false;
			}
			if(ball.x > width - 80) {
				V["V1"] = false; V["V2"] = true; V["T1"] = false;
			}
			Stylish(context, "SCORE: " + credits, "blue", "30px verdana", width/2, 40);
			if(hits < 1) {
				report.render(canvas); Stylish(context, "Play Again", "red", "30px verdana", width/2, height/2 - 30/2);
				menu.render(canvas); Stylish(context, "Menu", "green", "30px verdana", width/2, height/2 - 30/2 - 60);
				V["pause"] = true;
				if(Game.x && Game.y) {
					if(report.clicked()) {
						Game.x = false; Game.y = false; 
						hits = 5; credits = "0"; V["pause"] = false; Game.Open(Main);
					}
					if(menu.clicked()) {
						Game.x = false; Game.y = false; Game.Open(Menu); V["pause"] = false;
					}
				}
			}
			if(Game.x && Game.y) {
				if (Game.left) {
					Game.down = false; Game.left = false; player.speedX = -4; player.speedY = -2; player.width = 80; player.height = 130; //left
				} else if(Game.right) {
					Game.down = false; Game.right = false; player.speedX = 4; player.speedY = -2; player.width = 80; player.height = 130; //right
				} else if(Game.up) {
					Game.down = false; Game.up = false; player.speedY = -5; player.width = 80; player.height = 130; player.image = jump; //up
				} else if(Game.down) {
					player.speedX = 0; player.speedY = 5; player.height = 100; player.image = crouch; //down
				}
			}
			if(Game.keys && Game.keys[37]) { Game.down = false; player.speedX = -4; player.speedY = -2; player.width = 80; player.height = 130; } //left
			if(Game.keys && Game.keys[38]) { Game.down = false; player.speedY = -5; player.width = 80; player.height = 130; player.image = jump; } //up
			if(Game.keys && Game.keys[39]) { Game.down = false; player.speedX = 4; player.speedY = -2; player.width = 80; player.height = 130; } //right
			if(Game.keys && Game.keys[40]) { Game.down = false; player.speedX = 0; player.speedY = 5; player.image = crouch; } //down
		}
	};
}