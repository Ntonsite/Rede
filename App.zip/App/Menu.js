function Menu() {
	var canvas = V["canvas"], context = canvas.Context(), width = Game.Width, height = Game.Height;
	var walk = 1, up = height; introduction = false;
	var background = new Item({ image: V["bg.png"], x: 0, y: 0, width: width, height: height }); V["menu"] = true;
	var girl = new Item({ image: V["girl.png"], x: width/4 - 80/2 + 40, y: height - 150 - 80, width: 80, height: 150 });
	var boy = new Item({ image: V["boy.png"], x: width/4 * 3 - 80/2 - 40, y: height - 150 -80, width: 80, height: 150 });
	var logo = new Item({ image: V["logo.png"], x: width/2 - 200/2, y: height/2 - 200/2, width: 200, height: 220 });
	var back = new Item({ color: "#770000", font: "40px verdana", align: "center", x: width/2, y: height - 40 - 20 });
	var start = new Item({ color: "blue", font: "40px verdana", align: "center", x: width/2, y: height/2 - 20 * 3 });
	var about = new Item({ color: "blue", font: "40px verdana", align: "center", x: width/2, y: height/2 + 20 });
	var info = "ABOUT GAME - Rede Is an East African game originally from Tanzania. Mostly played by boys or girls during childhood. Though sometimes can also be played by adults. It is a physical Game which involves side, ups and down movement of the body between two throwers. The aim of these two throwers is to make sure the ball does not touch the body of the player.";
	var Stylish = function(o, text, color, font, x, y, a) {
		o.font = font; o.shadowColor = "black"; o.shadowBlur = a ? a : 10; o.lineWidth = a ? a: 10; o.strokeStyle = "white"; o.strokeText(text, x, y); 
		o.shadowBlur = 0; o.fillStyle = color; o.fillText(text, x, y); o.textBaseline = "middle"; o.textAlign = "center";
	};
	var Wrap = function(o, text, color, font, x, y, maxWidth, lineHeight, a) {
		var words = text.toString().split(' '), line = App.Config.FLAVOR; var lines = 1;
		for(var n = 0; n < words.length; n++) {
			var line2 = line + words[n] + ' ', width = o.measureText(line2).width;
			if (width > maxWidth && n > 0) {
				Stylish(o, line.trim(), color, font, x, y, a); line = words[n] + ' '; y += lineHeight; lines++;
			} else {
				line = line2;
			}
		}
		Stylish(o, line.trim(), color, font, x, y, a);
		return lines;
	};
	return {
		Activity: function() {
			canvas.Clear(width, height); Game.frame += 1;
			background.render(canvas);
			if(V["menu"]) {
				Stylish(context, "START GAME", "blue", "40px verdana", width/2, height/2 - 20 * 3); start.text = "START GAME"; start.render(canvas); 
				Stylish(context, "ABOUT", "blue", "40px verdana", width/2, height/2 + 20); about.text = "ABOUT"; about.render(canvas); 
				if(Game.x && Game.y) {
					if(start.clicked()) {
						Game.x = false; Game.y = false; introduction = false; V["menu"] = false;
					}
					if(about.clicked()) {
						Game.x = false; Game.y = false; introduction = true; V["menu"] = false; Game.Audio.Play("music.mp3", true);
					}
				}
			} else {
				if(introduction) {
					Game.frame == 1 || Game.Wait(10) ? up -= 5 : null ; //logo.render(canvas);
					if(Wrap(context, info, "#000066", "30px verdana", width/2, up, width - 40, 40, 4) > height/2 + up) { V["menu"] = true; up = height; }
					Stylish(context, "Back", "#770000", "40px verdana", width/2, height - 40 - 20); back.text = "Back"; back.render(canvas);
					if(Game.x && Game.y) {
						if(back.clicked()) {
							Game.x = false; Game.y = false; V["menu"] = true;
						}
					}
				} else {
					Stylish(context, "CHOOSE PLAYER", "blue", "40px verdana", width/2, 60);
					boy.render(canvas); girl.render(canvas);
					if(Game.x && Game.y) {
						if(girl.clicked()) {
							Game.down = false; V["player"] = 1; Game.Open(Main);
						}
						if(boy.clicked()) {
							Game.down = false; V["player"] = 2; Game.Open(Main);
						}
					}
				}
			}
		}
	};
}