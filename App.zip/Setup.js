Engine.Import("*");
Engine.Import("UI");
Engine.Import("Util");
App.Manifest({
	version: "1.0",
	name: "Rede",
	author: "Innovation Hub255",
	description: null,
	icon: null
});
App.Config.DEBUG = true;
App.Script("Plugin/Game.js", function() {
	var Initialization = function(width, height) {
		var builder = function(a, b, c) { var d = []; for(var i = 0; i < a.length; i++) { d.push(b + "/" + a[i] + "." + c); } return d; };
		var sound = builder(["hit", "music"], "Res/Audio", "mp3");
		var images = builder(["bg", "idle0", "jump0", "crouch0", "idle1", "jump1", "crouch1", "ball", "logo", "girl", "boy",
			"V10", "V11", "V20", "V21"], "Res/Image", "png");
		//File.Preload.Audio(sound).Response(function(a, b) { V[a] = b; });
		File.Preload.Array(sound).Response(function(a, b) { V[a] = b; });
		File.Preload.Image(images).Response(function(a, b, c) {
			V[a] = b;
			if(c == 0) {
				var scenes = builder(["Menu", "Main"], "App", "js"), progress = 0;
				scenes.Loop(function(a, b) {
					App.Script(b, function() {
						progress++;
						if(progress == scenes.length) {
							Document.Clear("body").HTML();
							V["canvas"] = new Web.Canvas(width, height).Into("BODY");
							Game.Width = V["canvas"].Width(); Game.Height = V["canvas"].Height();
							Device.Mobile() ? Game.Resize(V["canvas"], App.Width, App.Height) : Game.Resize(V["canvas"], Game.Width, Game.Height) ;
							Game.Controllers("canvas"); Game.Open(Menu);
						}
					});
				});
			}
		});
	}
	Document.Clear("BODY").Content();
	Atom("#AAXX").C("#FFF").BS("cover").PO("absolute").T("50%").L("50%").TF("translate(-50%,-50%)").Done();
	if(Device.Mobile()) {
		Tag("DIV").ID("AAXX").Style("background: url(Res/Image/tap.png); width: 120px; height: 120px; color: #fff").Done().Get().onmousedown = function(e) {
			e.preventDefault(); Document.Clear("BODY").Content(); Tag("DIV").Text("Loading...").ID("AAXX").Style("color: #fff").Done();
			Device.Fullscreen("landscape"); Wait(function() { Initialization(App.Width, App.Height); }, 2000);
		};
	} else {
		Tag("DIV").Text("Loading...").ID("AAXX").Done(); Initialization(700, 500);
	}
});
Atom("*").M(0).P(0).B(0).BX(0).TC("none").US("none").OL("none").OV("hidden").THC("transparent").Done();
Atom(":fullscreen,::-webkit-full-screen,:-moz-full-screen,:-ms-full-screen").W("100%").H("100%").D("block").BG("#3F3F6F").C("#FFF").Done();
Atom("::-webkit-scrollbar-thumb").BG("#BBD").BX("4px").B("2px solid #3F3F6F").Done();
Atom("::-webkit-scrollbar").BG("#3F3F6F").W("8px").H("6px").Done();
Atom("HTML,BODY").SBC("#BBD").SAC("#3F3F6F").STC("#3F3F6F").C("#FFF").BG("#000").FF("calibri").FS("14px").W("100%").Done();
Atom("CANVAS").C("#FFF").BG("#FFF").BS("cover").PO("absolute").T("50%").L("50%").TF("translate(-50%,-50%)").Done();
Document.Set("body").Attr("onselectstart", "return false"); Document.Set("body").Attr("ondragstart", "return false");